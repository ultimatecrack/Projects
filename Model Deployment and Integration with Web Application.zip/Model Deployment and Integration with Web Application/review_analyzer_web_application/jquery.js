function submit_review() {
	review = $('#review').val();

	if (review == ''){
		alert('Please fill the review!');
		return false;
	}

	var jsonObjects = {satisfaction_level:review};

	jQuery.ajax({
	          url: "http://127.0.0.1:8000/predict",
	          type: "POST",
	          data: JSON.stringify(jsonObjects),
	          dataType: "json",
	          xhrFields: {
		      withCredentials: true
		  },
	          beforeSend: function(x) {
	            if (x && x.overrideMimeType) {
	              x.overrideMimeType("application/j-son;charset=UTF-8");
	            }
	          },
	          success: function(result) {
	          	review_type = result.prediction;
	          	if(review_type == 'Negative') {
	          		message = 'We will try to improve our quality !';
	          	}else{
	          		message = 'Happy to serve you!'
	          	}
	          	$('#message').text(message);
				$('#message_parent').show();	
	          }
	});
}