# -*- coding: utf-8 -*-
"""
Created on Fri Jun 26 23:25:00 2020

@author: Rakesh Panigrahy
"""


import joblib
#import numpy as np
#import matplotlib.pyplot as plt
#import pandas as pd
#import nltk
import re
#nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

from sklearn.feature_extraction.text import CountVectorizer
corpus = joblib.load('corpos')
cv = CountVectorizer(max_features = 1500)
cv.fit_transform(corpus).toarray()

classifier = joblib.load('review_classifier')

new_review = 'I love you !'
new_review = re.sub('[^a-zA-Z]', ' ', new_review)
new_review = new_review.lower()
new_review = new_review.split()
ps = PorterStemmer()
all_stopwords = stopwords.words('english')
all_stopwords.remove('not')


new_review = [ps.stem(word) for word in new_review if not word in set(all_stopwords)]
new_review = ' '.join(new_review)
new_corpus = [new_review]
new_X_test = cv.transform(new_corpus).toarray()
new_y_pred = classifier.predict(new_X_test)
print(new_y_pred)